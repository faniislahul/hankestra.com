<html>
<head>
<title>HANKESTRA</title>

<script src="js/jquery.min.js"></script>
 <script src="js/jquery-1.11.1.js"></script>
 <script src="js/jquery.fullPage.js"></script>


<link href="css/jquery.fullPage.css" rel="stylesheet" />
<link href="css/css.css" rel="stylesheet" />
<script type="text/javascript">
		$(document).ready(function() {
			$('#fullpage').fullpage({
				
				sectionsColor: ['#000', '#000', '#000', '#000', '#000', '#000'],
				navigation: true,
				navigationPosition: 'right',
				navigationTooltips: ['Home', 'Profil-Hankestra','Profil-Han', 'Profil-Feri', 'Profil-Kucing', 'Profil-Leon'],
				showActiveTooltip: false,
				scrollingSpeed: 800,
				css3: true, 

			});
		});
	</script>



</head>
<body>
<div id="fullpage">
<div class="section" id="home">
	
	<p class="mainH" style="z-index:11;">HANKESTRA</p>
	<p class="tagline" style="z-index:11;">Brotherhood, dream, and luck!</p>
	


</div>
<div class="section" id="section1">
	<div class="centerbox">
		<p class="subhead">HANKESTRA</p>
		<p class="subtext">
			Secara formal HANKESTRA terbentuk bulan November 2014.
			Sebuah kelompok musik yang kini beranggotakan: 
			Han Farhani pada vokal dan gitar, Feri H. Said pada gitar, 
			Hamdan Arrasyid (Kucing) pada bass, dan Leon Nauval Lolang pada 
			perkusi dan harmonika. Saat ini berkibar di dunia permusikan akustik 
			di Kota Malang. Musik yang dibawakan adalah sejenis akustik yang 
			beberapa terpengaruh dari musik ballad, blues, dan sejenisnya. 
			HANKESTRA lebih setuju untuk disebut sebagai sebuah keluarga 
			karena yang menjadi core value dalam bermusiknya adalah 
			“Persaudaraan, cita-cita, dan keberuntungan!” yang siapa saja 
			dapat mengartikannya secara luas dan mudah. Sehari-hari 
			HANKESTRA aktif berlatih, bermusik, dan ngopi di Galeri Teratai</p>

	</div>
	

</div>
<div class="section" id="han">
<div class="wrapbox">
<p class="subhead">Han Farhani</p>
<p class="subtext">Han Farhani lahir di Ketapang, 1 Oktober 1993. 
	Dibesarkan di Kota Mataram dan bermusik sejak duduk di bangku SMP. 
	Mengidolakan John Lennon. Di sela bermusik menggeluti dunia akuntansi.</p>
</div>

</div>
<div class="section" id="feri">
<div class="rightbox" >
<p class="subhead">Feri H. Said </p>
<p class="subtext">Feri H. Said lahir di Malang, 10 Maret 1979. 
	Menyukai jenis musik klasik. Pemilik Galeri Teratai di Taman Rekreasi Kota Malang. 
	Keinginan untuk jujur dan sederhana. Aktif berkarya dalam musik dan seni rupa. 
	</br>Motto hidup: “Urip sampai mati berkesenian”</p>
</div>
</div>

<div class="section" id="kucing">
<div class="rightbox">
<p class="subhead">Hamdan Arrasyid (Kucing) </p>
<p class="subtext">Hamdan Arrasyid lahir di Batu, 13 Oktober 1994. 
	Dibesarkan di Banyuwangi. 

	Menempuh pendidikan jurusan Psikologi di UIN Maliki Malang. 
	Menyukai jenis musik rock dan dangdut, influence musik: 
	The Police, Float, Dialog Dini Hari. Bermusik sejak SMP dan 
	akrab dengan instrumen bass sejak tahun 2006. Semangat hidup indie.
	 </br>Motto hidup: “Life to lives and love to loves”</p>
</div>
</div>

<div class="section" id="leon">
<div class="wrapbox" style="width:40%;">
<p class="subhead">Leon Nauval Lolang </p>
<p class="subtext">Leon Nauval Lolang lahir di Jakarta, 25 September 1994. 
	Menempuh pendidikan jurusan sosiologi di Universitas Brawijaya. 
	Influence berkarya: Keluarga, John Bonham (Led Zeppelin), 
	Keith Moon (The Who), Mitch Mitchell (The Jimi Hendrix Experience), 
	Kantata Takwa, Sutardji Calzoum Bachri, Homicide, Wiji Tukul, 
	Joko Pinurbo. Menyukai puisi, filsafat, ilmu sosial, olahraga, dan traveling. 
</br>Motto hidup: “Saat kemungkinan itu sudah mati, berarti manusia itu mati. Karena kelahiran manusia itu sendiri dipenuhi dengan kemungkinan”</p>
</div>
</div>

</div>
</body>

</html>