<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use DB,Session, Redirect;
use App\Http\Requests;
use App\Http\Controllers\Controller;

class Index extends Controller
{
	public function index()
	{
		return view('index');
	}


}